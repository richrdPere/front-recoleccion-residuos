import { CommonModule, DatePipe, } from '@angular/common';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, firstValueFrom } from 'rxjs';
import Swal from 'sweetalert2';

// Directives
import { UppercaseDirective } from 'src/app/shared/directives/uppercase.directive';

// Service
import { VehiculosService } from '../../services/vehiculos.service';

// Interface
import { EstadoOperativoVehiculo, TipoVehiculo, VehiculoData, VehiculosPaginadosFilters } from '../../models';

// Componentes
import { VehiculosFormComponent } from '../components/vehiculos-form/vehiculos-form.component';
import { VehiculosViewComponent } from '../components/vehiculos-view/vehiculos-view.component';
import { VehiculosEstadoOperativoComponent } from '../components/vehiculos-estado-operativo/vehiculos-estado-operativo.component';

@Component({
  selector: 'app-vehiculos-page',
  imports: [
    DatePipe,
    FormsModule,
    CommonModule,
    UppercaseDirective,
    VehiculosFormComponent,
    VehiculosViewComponent,
    VehiculosEstadoOperativoComponent
  ],
  templateUrl: './vehiculos-page.component.html',
  styles: ``,

})
export class VehiculosPageComponent implements OnInit {

  // Vehiculos
  vehiculos: VehiculoData[] = [];
  vehiculo_id: number | null = null;
  isLoading = true;

  mostrarModal = false;
  mostrarModalView = false;
  modoEdicion = false;
  vehiculoSeleccionado: any = null;

  mostrarModalEstadoOperativo = false;
  vehiculoEstadoSeleccionado: VehiculoData | null = null;

  searchTimeout: any;

  // Search
  searchBusqueda: string = '';
  estadoOperativoBusqueda: EstadoOperativoVehiculo | '' = '';
  tipoVehiculoBusqueda: TipoVehiculo | '' = '';

  // Paginado
  page = 1;
  limit = 5;
  totalItems = 0;
  totalPages = 0;
  currentPage = 1;

  pageSizeOptions = [5, 10, 20, 50];

  // Estado switch
  readonly vehiculoCambiandoEstado = new Set<string>();

  // Selectores
  readonly tiposVehiculo: {
    value: TipoVehiculo;
    label: string;
  }[] = [
      {
        value: 'CAMION_COMPACTADOR',
        label: 'CAMIÓN COMPACTADOR',
      },
      // {
      //   value: 'CAMION_BARANDA',
      //   label: 'CAMIÓN BARANDA',
      // },
      {
        value: 'CAMION_VOLQUETE',
        label: 'CAMIÓN VOLQUETE',
      },
      {
        value: 'MOTOFURGON',
        label: 'MOTOFURGÓN',
      },
      // {
      //   value: 'OTRO',
      //   label: 'OTRO',
      // },
    ];

  readonly estadosOperativos: {
    value: EstadoOperativoVehiculo;
    label: string;
  }[] = [
      {
        value: 'DISPONIBLE',
        label: 'DISPONIBLE',
      },
      {
        value: 'EN_RUTA',
        label: 'EN RUTA',
      },
      {
        value: 'EN_MANTENIMIENTO',
        label: 'EN MANENIMIENTO',
      },
      {
        value: 'FUERA_DE_SERVICIO',
        label: 'FUERA DE SERVICIO',
      },
    ];


  constructor(
    private vehiculosService: VehiculosService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.getVehiculosPaginated();
  }

  // ================================
  // Methods
  // ================================
  getVehiculosPaginated() {
    const params: VehiculosPaginadosFilters = {
      page: this.page,
      limit: this.limit,
      search: this.searchBusqueda,
      estado_operativo: this.estadoOperativoBusqueda || undefined,
      tipo_vehiculo: this.tipoVehiculoBusqueda || undefined,
      // sortOrder: 'ASC'
    };

    this.isLoading = true;

    this.vehiculosService.getVehiculosPaginated(params)
      .pipe(
        finalize(() => {
          this.isLoading = false;
          this.cdr.markForCheck();
        }),
      )
      .subscribe({
        next: (res) => {

          const paginacion = res.data;

          this.vehiculos = paginacion.items;
          this.totalItems = paginacion.total;
          this.currentPage = paginacion.page;

          this.page = paginacion.page;
          this.limit = paginacion.limit;
          this.totalPages = paginacion.totalPages;
        },
        error: (err) => {
          console.error(err);
          this.isLoading = false;

          this.vehiculos = [];
          this.totalItems = 0;
          this.totalPages = 0;
        }
      });
  }

  // - Eliminar vehiculo
  eliminarVehiculo(vehiculo: VehiculoData) {
    Swal.fire({
      title: '¿Eliminar unidad?',
      text: `Se eliminará la unidad ${vehiculo.codigo}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6'
    }).then((result) => {

      if (result.isConfirmed) {

        this.vehiculosService.deleteVehiculo(vehiculo.id_vehiculo)
          .subscribe({
            next: () => {

              Swal.fire({
                icon: 'success',
                title: 'Unidad eliminada',
                text: 'La unidad fue eliminada correctamente',
                timer: 2000,
                showConfirmButton: false
              });

              this.getVehiculosPaginated();
            },
            error: (err) => {

              console.error(err);

              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se pudo eliminar la unidad'
              });

            }
          });
      }
    });
  }

  // Editar vehiculo
  editarUnidad(vehiculo: VehiculoData) {
    this.modoEdicion = true;
    this.vehiculoSeleccionado = { ...vehiculo };
    this.mostrarModal = true;
  }

  // Ver vehiculo
  verVehiculo(vehiculo: VehiculoData) {
    this.vehiculo_id = vehiculo.id_vehiculo;
    this.mostrarModalView = true;
  }


  // *********************************************************
  // - CAMBIAR ESTADO OPERATIVO
  // *********************************************************
  abrirModalEstadoOperativo(vehiculo: VehiculoData): void {
    this.vehiculoEstadoSeleccionado = vehiculo;
    this.mostrarModalEstadoOperativo = true;
  }

  cerrarModalEstadoOperativo(): void {
    this.mostrarModalEstadoOperativo = false;
    this.vehiculoEstadoSeleccionado = null;
  }

  onEstadoOperativoActualizado(vehiculoActualizado: VehiculoData): void {
    this.vehiculos = this.vehiculos.map((vehiculo) =>
      vehiculo.id_vehiculo === vehiculoActualizado.id_vehiculo
        ? vehiculoActualizado
        : vehiculo,
    );
  }

  // - CAMBIAR ESTADO
  async cambiarEstado(
    vehiculo: VehiculoData,
    event: Event,
  ): Promise<void> {
    const input = event.target as HTMLInputElement;
    const vehiculoId = String(vehiculo.id_vehiculo);

    // El navegador ya cambió el checkbox; restauramos su estado.
    input.checked = vehiculo.estado;

    if (this.vehiculoCambiandoEstado.has(vehiculoId)) {
      return;
    }

    const nuevoEstado = !vehiculo.estado;

    this.vehiculoCambiandoEstado.add(vehiculoId);
    this.cdr.markForCheck();

    try {
      const resultado = await Swal.fire({
        icon: 'warning',
        title: nuevoEstado
          ? '¿Activar vehiculo?'
          : '¿Desactivar vehiculo?',

        text: nuevoEstado
          ? `Se habilitará el vehiculo con código: ${vehiculo.codigo}.`
          : `Se deshabilitará el vehiculo con código: ${vehiculo.codigo}.`,

        showCancelButton: true,
        confirmButtonText: nuevoEstado
          ? 'Sí, activar'
          : 'Sí, desactivar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: nuevoEstado ? '#16a34a' : '#dc2626',

        reverseButtons: true,
        focusCancel: true,
        showLoaderOnConfirm: true,

        allowOutsideClick: () => !Swal.isLoading(),
        allowEscapeKey: () => !Swal.isLoading(),

        preConfirm: async () => {
          try {
            const response = await firstValueFrom(
              this.vehiculosService.changeEstado(
                vehiculo.id_vehiculo,
                { estado: nuevoEstado },
              ),
            );

            if (!response.success) {
              Swal.showValidationMessage(
                response.message || 'No se pudo actualizar el estado.',
              );
              return false;
            }

            return response;
          } catch (error: unknown) {
            const err = error as {
              error?: { message?: unknown } | string;
              message?: unknown;
            } | null;

            const mensajeBackend = typeof err?.error === 'string'
              ? err.error
              : err?.error?.message;

            const mensaje = mensajeBackend ?? err?.message;

            Swal.showValidationMessage(
              typeof mensaje === 'string' && mensaje.trim()
                ? mensaje
                : 'Ocurrió un error al actualizar el estado del vehiculo.',
            );

            return false;
          }
        },
      });

      if (!resultado.isConfirmed || !resultado.value) {
        return;
      }

      // Usa el estado confirmado por el backend.
      vehiculo.estado = resultado.value.data.estado;
      vehiculo.updated_at = resultado.value.data.updated_at;

      input.checked = vehiculo.estado;
      this.cdr.markForCheck();

      void Swal.fire({
        icon: 'success',
        title: vehiculo.estado
          ? 'Vehiculo activado'
          : 'Vehiculo desactivado',
        text: resultado.value.message,
        timer: 1800,
        showConfirmButton: false,
      });
    } finally {
      this.vehiculoCambiandoEstado.delete(vehiculoId);
      this.cdr.markForCheck();
    }
  }

  estaCambiandoEstado(vehiculo: VehiculoData): boolean {
    return this.vehiculoCambiandoEstado.has(String(vehiculo.id_vehiculo));
  }

  // ================================
  // Helpers methods
  // ================================
  get hayFiltros(): boolean {
    return !!(
      this.searchBusqueda.trim() ||
      this.estadoOperativoBusqueda ||
      this.tipoVehiculoBusqueda
    );
  }

  fotoVehiculoUrl(
    ruta: string | null,
  ): string | null {
    return this.vehiculosService
      .resolverFotoUrl(ruta);
  }

  getIconoUnidad(
    tipo: string | null | undefined,
  ): string {
    const tipoNormalizado = tipo?.trim().toUpperCase() ?? '';

    if (
      tipoNormalizado.includes('MOTO')
    ) {
      return 'fa-motorcycle';
    }

    return 'fa-truck-field-un';
  }

  onSearchChange() {
    clearTimeout(this.searchTimeout);

    this.searchTimeout = setTimeout(() => {
      this.page = 1;
      this.getVehiculosPaginated();
    }, 300);
  }

  onPageSizeChange() {
    this.currentPage = 1; // vuelve a la primera página
  }

  onFiltroChange() {
    this.page = 1;
    this.getVehiculosPaginated();
  }

  cambiarPagina(nuevaPagina: number) {
    if (nuevaPagina < 1 || nuevaPagina > this.totalPages) return;
    this.page = nuevaPagina;
    this.getVehiculosPaginated();
  }

  cambiarLimite() {
    this.limit = Number(this.limit);
    this.page = 1;
    this.getVehiculosPaginated();
  }

  getTipoVehiculo(tipo: TipoVehiculo): {
    icon: string;
    label: string;
    class: string;
  } {
    const tipos: Record<
      TipoVehiculo,
      { icon: string; label: string; class: string }
    > = {
      CAMION_COMPACTADOR: {
        icon: 'fa-truck',
        label: 'COMPACTADOR',
        class: 'badge-info',
      },
      CAMION_BARANDA: {
        icon: 'fa-truck-pickup',
        label: 'BARANDA',
        class: 'badge-accent',
      },
      CAMION_VOLQUETE: {
        icon: 'fa-truck-moving',
        label: 'VOLQUETE',
        class: 'badge-success',
      },
      MOTOFURGON: {
        icon: 'fa-motorcycle',
        label: 'MOTOFURGÓN',
        class: 'badge-primary',
      },
      OTRO: {
        icon: 'fa-car-side',
        label: 'OTRO',
        class: 'badge-error',
      },
    };

    return tipos[tipo] ?? {
      icon: 'fa-truck',
      label: 'NO ESPECIFICADO',
      class: 'badge-neutral',
    };
  }

  getEstadoOperativoClass(estado: string): {
    label: string;
    class: string;
  } {
    const map: Record<string, {
      label: string;
      class: string;
    }> = {
      DISPONIBLE: {
        label: 'DISPONIBLE',
        class: 'badge-info'
      },
      ASIGNADO: {
        label: 'ASIGNADO',
        class: 'badge-primary'
      },
      EN_RUTA: {
        label: 'EN RUTA',
        class: 'badge-success'
      },
      EN_MANTENIMIENTO: {
        label: 'MANTENIMIENTO',
        class: 'badge-secondary'
      },
      FUERA_DE_SERVICIO: {
        label: 'FUERA_DE_SERVICIO',
        class: 'badge-error'
      }
    };

    return map[estado] || {
      label: estado,
      class: 'badge-neutral'
    };
  }

  limpiarFiltros(): void {
    this.searchBusqueda = '';
    this.estadoOperativoBusqueda = '';
    this.tipoVehiculoBusqueda = '';
    this.page = 1;

    this.getVehiculosPaginated();
  }

  // ================================
  // Modales methods
  // ================================
  abrirModal() {
    this.modoEdicion = false;
    this.vehiculoSeleccionado = null;
    this.mostrarModal = true;
  }

  cerrarModal() {
    this.mostrarModal = false;
  }

  cerrarModalInfo() {
    this.mostrarModalView = false;
    this.vehiculo_id = null;
  }
}
