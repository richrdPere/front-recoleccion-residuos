import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize, Subscription } from 'rxjs';
import Swal from 'sweetalert2';

// Service
import { RutaVersionService } from '../../services/ruta-version.service';

// Interfaces
import { RutaPuntoData, RutaVersionConPuntosData, } from '../../interfaces/rutas';
import { RutaVersionFormComponent } from './ruta-version-form/ruta-version-form.component';
import { RutaPuntoComponent } from '../ruta-punto/ruta-punto.component';
import { ZonaPoligonoGeoJSON } from 'src/app/features/zonas/interfaces';


@Component({
  selector: 'ruta-versiones',
  standalone: true,
  imports: [CommonModule, RutaVersionFormComponent, RutaPuntoComponent],
  templateUrl: './ruta-versiones.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RutaVersionesComponent implements OnChanges, OnDestroy {

  // *********************************************************
  // INPUTS / OUTPUTS
  // *********************************************************
  @Input() mostrarModal = false;
  @Input() ruta_id: number | null = null;
  @Input() poligono_geojson: ZonaPoligonoGeoJSON | null = null;

  @Output() modalCerrado = new EventEmitter<void>();
  @Output() gestionarPuntos = new EventEmitter<RutaVersionConPuntosData>();

  // *********************************************************
  // DEPENDENCIAS
  // *********************************************************
  private readonly rutaVersionService = inject(RutaVersionService);
  private consulta?: Subscription;

  // *********************************************************
  // ESTADO
  // *********************************************************
  mostrarModalVersionForm = false;
  modalWidthClass = 'max-w-4xl';

  modoEdicionVersion = false;
  versionParaEditar: RutaVersionConPuntosData | null = null;

  readonly mostrarPuntos = signal(false);
  readonly cargando = signal(false);
  readonly error = signal<string | null>(null);

  readonly versiones = signal<RutaVersionConPuntosData[]>([]);
  readonly indiceSeleccionado = signal<number | null>(null);

  // ID de la versión que se está activando.
  readonly activandoVersionId = signal<number | null>(null);

  readonly versionSeleccionada =
    computed<RutaVersionConPuntosData | null>(() => {
      const indice = this.indiceSeleccionado();

      return indice === null
        ? null
        : this.versiones()[indice] ?? null;
    });

  readonly puntosOrdenados = computed<RutaPuntoData[]>(() =>
    [...(this.versionSeleccionada()?.puntos ?? [])].sort(
      (a, b) =>
        a.orden - b.orden ||
        a.id_ruta_punto - b.id_ruta_punto,
    ),
  );

  // *********************************************************
  // CICLO DE VIDA
  // *********************************************************
  ngOnChanges(changes: SimpleChanges): void {
    if (!changes['mostrarModal'] && !changes['ruta_id']) {
      return;
    }

    if (!this.mostrarModal) {
      this.limpiar();
      return;
    }

    this.mostrarPuntos.set(false);
    this.indiceSeleccionado.set(null);

    this.setModalWidth('xl');
    this.cargarVersiones();
  }

  ngOnDestroy(): void {
    this.consulta?.unsubscribe();
  }

  // *********************************************************
  // 1. OBTENER VERSIONES
  // *********************************************************
  cargarVersiones(): void {
    // Cancelar primero evita que una respuesta anterior
    // reemplace los datos de otra ruta.
    this.consulta?.unsubscribe();

    // Conservar la selección cuando el hijo actualice sus puntos.
    const idVersionAnterior = this.versionSeleccionada()?.id_ruta_version ?? null;

    this.versiones.set([]);
    this.indiceSeleccionado.set(null);
    this.error.set(null);

    const idRuta = this.ruta_id;

    if (idRuta === null || !Number.isSafeInteger(idRuta) || idRuta <= 0) {
      this.cargando.set(false);
      this.mostrarPuntos.set(false);
      this.error.set('El identificador de la ruta no es válido.');
      return;
    }

    this.cargando.set(true);

    this.consulta = this.rutaVersionService
      .getVersionesByRuta(idRuta)
      .pipe(
        finalize(() => this.cargando.set(false)),
      )
      .subscribe({
        next: (response) => {
          if (!response.success) {
            this.error.set(
              response.message ||
              'No se pudieron obtener las versiones.',
            );
            return;
          }

          const versiones = response.data ?? [];

          this.versiones.set(versiones);

          const indiceAnterior = versiones.findIndex(
            (version) =>
              version.id_ruta_version === idVersionAnterior,
          );

          this.indiceSeleccionado.set(
            indiceAnterior >= 0
              ? indiceAnterior
              : versiones.length > 0
                ? 0
                : null,
          );

          // Si la versión consultada ya no existe, ocultar su panel.
          if (indiceAnterior < 0) {
            this.mostrarPuntos.set(false);
          }
        },
        error: (error: unknown) => {
          this.error.set(this.obtenerMensajeError(error));
        },
      });
  }

  // *********************************************************
  // 2. SELECCIONAR VERSIÓN
  // *********************************************************
  seleccionarVersion(indice: number): void {
    if (!this.versiones()[indice]) {
      return;
    }

    this.indiceSeleccionado.set(indice);
  }

  abrirEditarPunto($event: RutaPuntoData) {
    throw new Error('Method not implemented.');
  }
  abrirCrearPunto($event: number) {
    throw new Error('Method not implemented.');
  }

  // *********************************************************
  // 3. ABRIR GESTIÓN DE PUNTOS
  // *********************************************************
  abrirGestionPuntos(): void {
    const version = this.versionSeleccionada();

    if (version) {
      this.gestionarPuntos.emit(version);
    }
  }

  // *********************************************************
  // 4. FORMULARIO DE CREACIÓN / EDICIÓN
  // *********************************************************
  abrirVersionForm(): void {
    if (
      this.ruta_id === null ||
      !Number.isSafeInteger(this.ruta_id) ||
      this.ruta_id <= 0
    ) {
      return;
    }

    this.modoEdicionVersion = false;
    this.versionParaEditar = null;
    this.mostrarModalVersionForm = true;
  }

  abrirEditarVersion(version: RutaVersionConPuntosData): void {
    if (
      !Number.isSafeInteger(version.id_ruta_version) ||
      version.id_ruta_version <= 0
    ) {
      return;
    }

    this.modoEdicionVersion = true;
    this.versionParaEditar = version;
    this.mostrarModalVersionForm = true;
  }

  cerrarVersionForm(): void {
    this.mostrarModalVersionForm = false;
    this.modoEdicionVersion = false;
    this.versionParaEditar = null;
  }

  onVersionCreada(): void {
    this.cerrarVersionForm();
    this.cargarVersiones();
  }

  onVersionActualizada(): void {
    this.cerrarVersionForm();
    this.cargarVersiones();
  }

  // *********************************************************
  // 5. CERRAR
  // *********************************************************
  cerrarModal(): void {
    this.limpiar();
    this.modalCerrado.emit();
  }

  // *********************************************************
  // 6. VISUALIZACIÓN DE PUNTOS DENTRO DEL MODAL
  // *********************************************************
  verPuntosVersion(indice: number): void {
    if (!this.versiones()[indice]) {
      return;
    }

    this.seleccionarVersion(indice);
    this.mostrarPuntos.set(true);
  }

  ocultarPuntos(): void {
    this.mostrarPuntos.set(false);
  }

  // *********************************************************
  // 7. ACTIVAR O DESACTIVAR UNA VERSION
  // *********************************************************
  activarVersion(
    version: RutaVersionConPuntosData,
    event: Event,
  ): void {
    const checkbox = event.target as HTMLInputElement;

    // Mantener el estado confirmado hasta recibir la respuesta.
    checkbox.checked = version.vigente;

    if (
      version.vigente ||
      !version.estado ||
      this.activandoVersionId() !== null ||
      this.cargando()
    ) {
      return;
    }

    const idVersion = version.id_ruta_version;

    if (!Number.isSafeInteger(idVersion) || idVersion <= 0) {
      return;
    }

    this.activandoVersionId.set(idVersion);

    this.rutaVersionService
      .activateRutaVersion(idVersion)
      .pipe(
        finalize(() => {
          this.activandoVersionId.set(null);
        }),
      )
      .subscribe({
        next: (response) => {
          if (!response.success) {
            void Swal.fire({
              icon: 'error',
              title: 'No se pudo activar la versión',
              text: response.message || 'Inténtalo nuevamente.',
            });

            return;
          }

          // Consultar nuevamente para reflejar qué versión quedó vigente.
          this.cargarVersiones();

          void Swal.fire({
            icon: 'success',
            title: 'Versión activada',
            text: response.message ||
              'La versión se estableció como vigente.',
            timer: 1800,
            showConfirmButton: false,
          });
        },
        error: (error: unknown) => {
          const mensaje = this.obtenerMensajeError(error);

          // Conservar el estado confirmado de la versión.
          checkbox.checked = version.vigente;

          void Swal.fire({
            icon: 'error',
            title: 'No se pudo activar la versión',
            text: mensaje,
            confirmButtonText: 'Aceptar',
          });
        },
      });
  }

  // *********************************************************
  // MÉTODOS PRIVADOS
  // *********************************************************
  private limpiar(): void {
    this.consulta?.unsubscribe();
    this.consulta = undefined;

    this.modoEdicionVersion = false;
    this.versionParaEditar = null;

    this.cargando.set(false);
    this.error.set(null);
    this.versiones.set([]);
    this.indiceSeleccionado.set(null);
    this.mostrarPuntos.set(false);
    this.mostrarModalVersionForm = false;
  }

  private obtenerMensajeError(error: unknown): string {
    const textoValido = (valor: unknown): string | null =>
      typeof valor === 'string' && valor.trim()
        ? valor.trim()
        : null;

    const leerMensaje = (valor: unknown): string | null => {
      if (!valor || typeof valor !== 'object') {
        return null;
      }

      return textoValido(
        (valor as { message?: unknown }).message,
      );
    };

    const mensajeDirecto = textoValido(error);

    if (mensajeDirecto) {
      return mensajeDirecto;
    }

    if (error && typeof error === 'object') {
      const objeto = error as {
        message?: unknown;
        error?: unknown;
        details?: unknown;
      };

      const mensaje =
        leerMensaje(objeto.details) ??
        leerMensaje(objeto.error) ??
        textoValido(objeto.message);

      if (mensaje) {
        return mensaje;
      }
    }

    return 'No se pudo activar la versión de la ruta.';
  }

  contarPuntosHabilitados(puntos: RutaPuntoData[]): number {
    return puntos.filter(
      (punto) => punto.estado && punto.deleted_at === null,
    ).length;
  }

  setModalWidth(
    size: 'sm' | 'md' | 'lg' | 'xl' | 'full',
  ): void {
    const clases = {
      sm: 'max-w-md',
      md: 'max-w-xl',
      lg: 'max-w-4xl',
      xl: 'max-w-6xl',
      full: 'max-w-full w-[95vw]',
    };

    this.modalWidthClass = clases[size];
  }


}
