export const environment = {
  production: true,

  mapboxToken: 'pk.eyJ1IjoiNzMwODEyNDciLCJhIjoiY211eGh6c2FoMDVrOTJ6cHEybzQ1M3NscSJ9.X_Wjjs6H8uwwsNDRh77h4w',

  // apiUrl: 'https://recoleccion-calca-pruebas.duckdns.org/api/',
  // socketUrl: 'https://recoleccion-calca-pruebas.duckdns.org/',

  // URLS
  apiUrl: 'http://localhost:4000/api/',
  socketUrl: 'http://localhost:4000/',
};
