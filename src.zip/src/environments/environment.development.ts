export const environment = {
  production: false,

  // ApiKeys
   mapboxToken: 'pk.eyJ1IjoiNzMwODEyNDciLCJhIjoiY211eGh6c2FoMDVrOTJ6cHEybzQ1M3NscSJ9.X_Wjjs6H8uwwsNDRh77h4w',

  // URLS
  apiUrl: 'http://localhost:4000/api/',
  socketUrl: 'http://localhost:4000/',
};
